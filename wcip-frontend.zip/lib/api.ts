// Typed fetch client for the FastAPI backend.
// Handles token storage, Authorization injection, transparent refresh on 401,
// and consistent error shapes. Browser-only token storage (localStorage).

import type {
  MatchPrediction, Page, ScenarioComparison, Simulation, Team, TokenPair,
  TournamentResult, User, EloPoint, AdminAnalytics,
} from "./types";

const BASE = process.env.NEXT_PUBLIC_API_BASE || "/backend/api/v1";

const ACCESS_KEY = "wcip_access";
const REFRESH_KEY = "wcip_refresh";

export const tokenStore = {
  get access() {
    return typeof window === "undefined" ? null : localStorage.getItem(ACCESS_KEY);
  },
  get refresh() {
    return typeof window === "undefined" ? null : localStorage.getItem(REFRESH_KEY);
  },
  set(pair: TokenPair) {
    localStorage.setItem(ACCESS_KEY, pair.access_token);
    localStorage.setItem(REFRESH_KEY, pair.refresh_token);
  },
  clear() {
    localStorage.removeItem(ACCESS_KEY);
    localStorage.removeItem(REFRESH_KEY);
  },
};

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = "ApiError";
  }
}

interface RequestOptions {
  method?: string;
  body?: unknown;
  auth?: boolean;
  form?: boolean;       // send as x-www-form-urlencoded (login)
  retry?: boolean;      // internal: prevent infinite refresh loops
}

async function request<T>(path: string, opts: RequestOptions = {}): Promise<T> {
  const { method = "GET", body, auth = false, form = false, retry = true } = opts;
  const headers: Record<string, string> = {};
  let payload: BodyInit | undefined;

  if (form) {
    headers["Content-Type"] = "application/x-www-form-urlencoded";
    payload = new URLSearchParams(body as Record<string, string>).toString();
  } else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }

  if (auth && tokenStore.access) {
    headers["Authorization"] = `Bearer ${tokenStore.access}`;
  }

  const res = await fetch(`${BASE}${path}`, { method, headers, body: payload });

  if (res.status === 401 && auth && retry && tokenStore.refresh) {
    const refreshed = await tryRefresh();
    if (refreshed) return request<T>(path, { ...opts, retry: false });
  }

  if (!res.ok) {
    let detail = `Request failed (${res.status})`;
    try {
      const data = await res.json();
      detail = typeof data.detail === "string" ? data.detail
        : Array.isArray(data.detail) ? data.detail.map((d: { msg: string }) => d.msg).join(", ")
        : detail;
    } catch { /* non-JSON error body */ }
    throw new ApiError(res.status, detail);
  }

  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

async function tryRefresh(): Promise<boolean> {
  try {
    const pair = await request<TokenPair>("/auth/refresh", {
      method: "POST",
      body: { refresh_token: tokenStore.refresh },
      retry: false,
    });
    tokenStore.set(pair);
    return true;
  } catch {
    tokenStore.clear();
    return false;
  }
}

export const api = {
  // --- auth ---
  register: (email: string, password: string, full_name?: string) =>
    request<User>("/auth/register", { method: "POST", body: { email, password, full_name } }),
  login: async (email: string, password: string) => {
    const pair = await request<TokenPair>("/auth/login", {
      method: "POST", form: true, body: { username: email, password },
    });
    tokenStore.set(pair);
    return pair;
  },
  me: () => request<User>("/auth/me", { auth: true }),
  logout: () => tokenStore.clear(),

  // --- teams ---
  teams: (confederation?: string) =>
    request<Team[]>(`/teams${confederation ? `?confederation=${confederation}` : ""}`),
  team: (id: number) => request<Team>(`/teams/${id}`),
  eloHistory: (id: number) => request<EloPoint[]>(`/teams/${id}/elo-history`),

  // --- predictions ---
  simulateMatch: (body: unknown) =>
    request<MatchPrediction>("/match/simulate", { method: "POST", body }),
  simulateTournament: (body: unknown) =>
    request<TournamentResult>("/tournament/simulate", { method: "POST", body }),
  compareScenarios: (body: unknown) =>
    request<ScenarioComparison>("/scenario/compare", { method: "POST", body }),

  // --- simulations (authed) ---
  createSimulation: (body: unknown) =>
    request<{ id: number; status: string; task_id?: string; result?: TournamentResult }>(
      "/simulations", { method: "POST", body, auth: true }),
  listSimulations: (page = 1, page_size = 20) =>
    request<Page<Simulation>>(`/simulations?page=${page}&page_size=${page_size}`, { auth: true }),
  getSimulation: (id: number) => request<Simulation>(`/simulations/${id}`, { auth: true }),
  updateSimulation: (id: number, body: unknown) =>
    request<Simulation>(`/simulations/${id}`, { method: "PATCH", body, auth: true }),
  duplicateSimulation: (id: number) =>
    request<Simulation>(`/simulations/${id}/duplicate`, { method: "POST", auth: true }),
  deleteSimulation: (id: number) =>
    request<void>(`/simulations/${id}`, { method: "DELETE", auth: true }),

  // --- admin ---
  adminAnalytics: () => request<AdminAnalytics>("/admin/analytics", { auth: true }),
};
